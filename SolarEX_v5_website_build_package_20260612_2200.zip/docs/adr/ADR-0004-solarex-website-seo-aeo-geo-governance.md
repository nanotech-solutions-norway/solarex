# ADR-0004 — SolarEX Website SEO/AEO/GEO Governance

**Timestamp:** 22:00, 12.06.2026 Europe/Oslo

## Decision

Use GitHub as the SolarEX source-of-truth control plane for page inventory, metadata, claims, documentation, forms, ROI and release evidence.

## Scope

SolarEX v5.0 static website, GitHub Pages workflow, Domeneshop form/backend scaffolding, documentation register, ROI calculator and animation integration.

## Boundaries

No credentials, SQL secrets, admin credentials, private customer data or confidential files may be committed.

## Status

AUTO_APPROVED baseline; production publication requires final user approval.
