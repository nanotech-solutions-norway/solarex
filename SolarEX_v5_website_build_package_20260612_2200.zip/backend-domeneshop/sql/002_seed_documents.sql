INSERT INTO documents (document_key,title,file_name,document_type,language_code,public_download_allowed,classification,version_label) VALUES
('quartz-application-instructions','SolarEX Quartz Application Instructions','SolarEX Quartz Edition - Application Instructions.pdf','application-instructions','en',0,'PENDING_REVIEW','source pending public link'),
('titan-application-instructions','SolarEX Titan Application Instructions','SolarEX Titan Edition - Application Instructions.pdf','application-instructions','en',0,'PENDING_REVIEW','source pending public link'),
('sds-tds-placeholder','SolarEX SDS/TDS Placeholder','pending','SDS/TDS','en',0,'PENDING_REVIEW','awaiting final public files')
ON DUPLICATE KEY UPDATE title=VALUES(title), updated_at=CURRENT_TIMESTAMP;
