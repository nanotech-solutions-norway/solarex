SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE IF NOT EXISTS contact_messages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  form_key VARCHAR(100) NOT NULL,
  name VARCHAR(190) DEFAULT NULL,
  company VARCHAR(190) DEFAULT NULL,
  email VARCHAR(190) NOT NULL,
  phone VARCHAR(80) DEFAULT NULL,
  country VARCHAR(100) DEFAULT NULL,
  project_location VARCHAR(190) DEFAULT NULL,
  subject VARCHAR(190) DEFAULT NULL,
  message TEXT DEFAULT NULL,
  consent TINYINT(1) NOT NULL DEFAULT 0,
  source_page VARCHAR(255) DEFAULT NULL,
  user_agent VARCHAR(255) DEFAULT NULL,
  ip_hash CHAR(64) DEFAULT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'new',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_contact_created_at (created_at),
  INDEX idx_contact_email (email),
  INDEX idx_contact_form_key (form_key),
  INDEX idx_contact_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS technical_review_requests (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  contact_message_id BIGINT UNSIGNED DEFAULT NULL,
  name VARCHAR(190) DEFAULT NULL,
  company VARCHAR(190) DEFAULT NULL,
  email VARCHAR(190) NOT NULL,
  country VARCHAR(100) DEFAULT NULL,
  project_location VARCHAR(190) DEFAULT NULL,
  coating_interest VARCHAR(120) DEFAULT NULL,
  soiling_context TEXT DEFAULT NULL,
  message TEXT DEFAULT NULL,
  source_page VARCHAR(255) DEFAULT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'new',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_technical_created_at (created_at),
  INDEX idx_technical_email (email),
  INDEX idx_technical_status (status),
  CONSTRAINT fk_technical_contact FOREIGN KEY (contact_message_id) REFERENCES contact_messages(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS roi_calculator_submissions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(190) DEFAULT NULL,
  company VARCHAR(190) DEFAULT NULL,
  email VARCHAR(190) DEFAULT NULL,
  project_location VARCHAR(190) DEFAULT NULL,
  country VARCHAR(100) DEFAULT NULL,
  currency_code CHAR(3) DEFAULT NULL,
  exchange_rate_eur DECIMAL(18,8) DEFAULT NULL,
  pv_area_m2 DECIMAL(14,2) DEFAULT NULL,
  calculated_payload JSON DEFAULT NULL,
  source_page VARCHAR(255) DEFAULT NULL,
  ip_hash CHAR(64) DEFAULT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'new',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_roi_created_at (created_at),
  INDEX idx_roi_email (email),
  INDEX idx_roi_country (country),
  INDEX idx_roi_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS documents (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  document_key VARCHAR(120) NOT NULL,
  title VARCHAR(255) NOT NULL,
  file_name VARCHAR(255) DEFAULT NULL,
  document_type VARCHAR(80) DEFAULT NULL,
  language_code VARCHAR(10) DEFAULT 'en',
  public_download_allowed TINYINT(1) NOT NULL DEFAULT 0,
  download_url VARCHAR(500) DEFAULT NULL,
  classification VARCHAR(50) NOT NULL DEFAULT 'PENDING_REVIEW',
  version_label VARCHAR(80) DEFAULT NULL,
  checksum_sha256 CHAR(64) DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_documents_document_key (document_key),
  INDEX idx_documents_classification (classification),
  INDEX idx_documents_type (document_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS documentation_downloads (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  document_id BIGINT UNSIGNED DEFAULT NULL,
  document_key VARCHAR(120) DEFAULT NULL,
  name VARCHAR(190) DEFAULT NULL,
  company VARCHAR(190) DEFAULT NULL,
  email VARCHAR(190) DEFAULT NULL,
  country VARCHAR(100) DEFAULT NULL,
  source_page VARCHAR(255) DEFAULT NULL,
  ip_hash CHAR(64) DEFAULT NULL,
  download_status VARCHAR(50) NOT NULL DEFAULT 'requested',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_downloads_created_at (created_at),
  INDEX idx_downloads_document_key (document_key),
  INDEX idx_downloads_email (email),
  CONSTRAINT fk_download_document FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
