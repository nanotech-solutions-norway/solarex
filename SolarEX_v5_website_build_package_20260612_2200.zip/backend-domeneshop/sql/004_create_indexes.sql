CREATE INDEX idx_contact_company_country ON contact_messages(company, country);
CREATE INDEX idx_technical_company_country ON technical_review_requests(company, country);
CREATE INDEX idx_roi_project_location ON roi_calculator_submissions(project_location);
CREATE INDEX idx_documents_language_public ON documents(language_code, public_download_allowed);
