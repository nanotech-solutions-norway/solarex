<?php
declare(strict_types=1);
require_once __DIR__ . '/../../solarex_forms_private/src/bootstrap.php';
$payload = json_decode(file_get_contents('php://input'), true) ?: [];
$email = solarex_require_email($payload);
$formKey = solarex_clean($payload['form_key'] ?? 'commercial_discussion', 100);
try {
  $pdo = solarex_db($config);
  $stmt = $pdo->prepare('INSERT INTO contact_messages (form_key,name,company,email,country,project_location,message,consent,source_page,user_agent,ip_hash) VALUES (:form_key,:name,:company,:email,:country,:project_location,:message,:consent,:source_page,:user_agent,:ip_hash)');
  $stmt->execute(['form_key'=>$formKey,'name'=>solarex_clean($payload['name'] ?? null,190),'company'=>solarex_clean($payload['company'] ?? null,190),'email'=>$email,'country'=>solarex_clean($payload['country'] ?? null,100),'project_location'=>solarex_clean($payload['project_location'] ?? null,190),'message'=>solarex_clean($payload['message'] ?? null,5000),'consent'=>!empty($payload['consent'])?1:0,'source_page'=>solarex_clean($payload['source_page'] ?? null,255),'user_agent'=>solarex_clean($_SERVER['HTTP_USER_AGENT'] ?? null,255),'ip_hash'=>hash('sha256',($_SERVER['REMOTE_ADDR'] ?? '').'|solarex')]);
  solarex_json_response(['ok'=>true,'id'=>(int)$pdo->lastInsertId(),'message'=>'Submission received']);
} catch (Throwable $e) {
  error_log('SolarEX submit error: '.$e->getMessage());
  solarex_json_response(['ok'=>false,'error'=>'server_error','message'=>'Submission could not be processed.'],500);
}
