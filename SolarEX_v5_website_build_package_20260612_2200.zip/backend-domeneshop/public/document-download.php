<?php
declare(strict_types=1);
http_response_code(404); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>false,'message'=>'Document download route is pending approved public files.']);
