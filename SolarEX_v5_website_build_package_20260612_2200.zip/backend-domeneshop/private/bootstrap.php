<?php
declare(strict_types=1);
$config = require __DIR__ . '/config.local.php';
require_once __DIR__ . '/validation.php';
require_once __DIR__ . '/db.php';
