<?php
declare(strict_types=1);
function solarex_json_response(array $payload, int $status = 200): void { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); echo json_encode($payload); exit; }
function solarex_clean(?string $value, int $limit = 500): ?string { if ($value === null) return null; return mb_substr(trim($value),0,$limit); }
function solarex_require_email(array $data): string { $email = filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL); if (!$email) solarex_json_response(['ok'=>false,'error'=>'validation_failed','message'=>'Valid email is required.'],422); return $email; }
