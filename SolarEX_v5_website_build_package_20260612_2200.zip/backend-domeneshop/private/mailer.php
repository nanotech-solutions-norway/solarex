<?php
declare(strict_types=1);
// Mail transport intentionally disabled in public baseline until server-side settings are approved.
