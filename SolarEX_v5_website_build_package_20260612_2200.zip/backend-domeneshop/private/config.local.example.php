<?php
declare(strict_types=1);
return [
  'app_env' => 'production',
  'timezone' => 'Europe/Oslo',
  'db' => [
    'host' => 'YOUR_DOMENESHOP_DB_HOST',
    'port' => 3306,
    'database' => 'YOUR_DATABASE_NAME',
    'username' => 'YOUR_DATABASE_USER',
    'password' => 'YOUR_DATABASE_PASSWORD',
    'charset' => 'utf8mb4',
  ],
  'security' => [
    'allowed_origins' => ['https://www.solarex.no','https://solarex.no','https://nanotech-solutions-norway.github.io'],
    'admin_export_token_hash' => 'SET_HASH_ONLY_NOT_RAW_TOKEN',
    'rate_limit_per_ip_per_hour' => 60,
  ],
  'mail' => ['enabled' => false,'from_email' => 'no-reply@solarex.no','admin_email' => 'info@solarex.no'],
];
