# SolarEX v5.0 Project Memory

Generated memory/catalog files for source scans, decisions, actions, errors, evidence and validation results.
