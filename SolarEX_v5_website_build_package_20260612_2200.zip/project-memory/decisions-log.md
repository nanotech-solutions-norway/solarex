# SolarEX v5.0 Decisions Log

## Decision — DEC-20260612_2200

**Decision:** Use `nanotech-solutions-norway/solarex` as a fresh SolarEX v5.0 static GitHub Pages build target.
**Reason:** Repository is accessible and empty; blueprint names it as the primary repository.
**Alternatives considered:** Modify older `SolarEX-Final-recreate`; rejected for v5.0 because the blueprint names a new primary repo.
**Source evidence:** v5.0 playbook, GitHub repo scan, SEO/AEO/GEO implementation plans.
**Approval status:** AUTO_APPROVED

## Decision — DEC-20260612_2200-ANIM

**Decision:** Integrate the declared animation as iframe plus visual fallback and mark as `PENDING_REVIEW`.
**Reason:** The source is declared in the blueprint, but current environment could not validate reachability.
**Approval status:** PENDING_REVIEW
