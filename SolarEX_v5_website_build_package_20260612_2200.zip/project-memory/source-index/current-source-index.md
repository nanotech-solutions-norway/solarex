# SolarEX v5.0 Source Index — 22:00, 12.06.2026

## Scan result

- Primary GitHub repo: `nanotech-solutions-norway/solarex` — accessible, empty fresh build target.
- ROI repo: `nanotech-solutions-norway/SolarEX-ROI-Calculator` — accessible, existing static calculator source reviewed.
- Drive folder 1 — accessible; contains SolarEX v5.0 folder, Pictures, Quartz/Titan source files and application instructions.
- Drive folder 2 — accessible; contains ROI calculator folder, recreate/deployment/images/admin dashboard materials.
- Animation URL — declared source; live validation failed from current environment, therefore integration uses iframe plus fallback and remains `PENDING_REVIEW`.

## Classification

- Uploaded v5.0 blueprint: PUBLIC_APPROVED controlling source.
- Uploaded SEO/AEO/GEO reports: PUBLIC_APPROVED implementation support.
- Drive source files: INTERNAL_ONLY until each document/download is individually approved for public use.
- Animation source: PENDING_REVIEW for live validation.
