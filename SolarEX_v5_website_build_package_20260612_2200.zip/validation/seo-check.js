const fs=require('fs');
const path=require('path');
const seo=JSON.parse(fs.readFileSync(path.join(__dirname,'../content/solarex-seo-map.json'),'utf8'));
let bad=[];
const titles=new Set(), metas=new Set();
for(const p of seo){
  if(p.page_title.length>70) bad.push(`${p.page_id}: title too long`);
  if(p.meta_description.length>160) bad.push(`${p.page_id}: meta too long`);
  if(titles.has(p.page_title)) bad.push(`${p.page_id}: duplicate title`);
  if(metas.has(p.meta_description)) bad.push(`${p.page_id}: duplicate meta`);
  titles.add(p.page_title); metas.add(p.meta_description);
}
if(bad.length){ console.error(bad.join('\n')); process.exit(1); }
console.log(`SEO check passed: ${seo.length} records`);
