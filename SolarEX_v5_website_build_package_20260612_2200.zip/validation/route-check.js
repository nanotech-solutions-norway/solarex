const fs=require('fs');
const path=require('path');
const map=JSON.parse(fs.readFileSync(path.join(__dirname,'../content/solarex-page-map.json'),'utf8'));
let bad=[];
for(const p of map){
  const file=path.join(__dirname,'..',p.file_path);
  if(!fs.existsSync(file)) bad.push(`${p.route} missing ${p.file_path}`);
}
if(bad.length){ console.error(bad.join('\n')); process.exit(1); }
console.log(`Route check passed: ${map.length} routes`);
