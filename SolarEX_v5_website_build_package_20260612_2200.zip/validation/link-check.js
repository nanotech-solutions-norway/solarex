const fs=require('fs');
const path=require('path');
const routes=new Set(JSON.parse(fs.readFileSync(path.join(__dirname,'../content/solarex-page-map.json'),'utf8')).map(p=>p.route));
let bad=[];
function walk(d){
  return fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>{
    const p=path.join(d,e.name);
    return e.isDirectory() && !['.git','node_modules'].includes(e.name) ? walk(p) : e.isFile() ? [p] : [];
  });
}
for(const file of walk(path.join(__dirname,'..')).filter(f=>f.endsWith('.html'))){
  const s=fs.readFileSync(file,'utf8');
  for(const m of s.matchAll(/<a[^>]+href="(\/[^"#?]*)/g)){
    const href=m[1].endsWith('/')?m[1]:m[1]+'/';
    if(!routes.has(href)) bad.push(`${path.relative(path.join(__dirname,'..'),file)} -> ${m[1]}`);
  }
}
if(bad.length){ console.error(bad.join('\n')); process.exit(1); }
console.log('Link check passed');
