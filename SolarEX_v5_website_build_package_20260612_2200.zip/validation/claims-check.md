# Claims Check

All public performance, ROI, warranty, lifetime and mechanism claims must reference `content/solarex-claims-registry.json`.
