# Forms Check

Validate POST to Domeneshop endpoint, error-safe fallback, consent field and no-confidential-upload warning.
