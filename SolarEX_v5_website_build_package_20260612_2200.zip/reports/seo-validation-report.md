# SEO Validation Report

Generated SEO map. Local script validation is run separately and result is recorded in validation-reports.
